﻿local L = LibStub("AceLocale-3.0"):NewLocale("APR", "deDE")
if not L then return end

-- Author: Kamian
--@localization(locale="deDE", format="lua_additive_table", handle-unlocalized="ignore")@
