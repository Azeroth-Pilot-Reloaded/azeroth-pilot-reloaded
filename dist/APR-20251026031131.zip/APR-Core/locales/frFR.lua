﻿local L = LibStub("AceLocale-3.0"):NewLocale("APR", "frFR")
if not L then return end

-- Author: Neogeekmo
--@localization(locale="frFR", format="lua_additive_table", handle-unlocalized="ignore")@
