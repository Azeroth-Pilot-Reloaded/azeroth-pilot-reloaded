# Lib: HereBeDragons

## [2.15-release](https://github.com/Nevcairiel/HereBeDragons/tree/2.15-release) (2025-07-02)
[Full Changelog](https://github.com/Nevcairiel/HereBeDragons/compare/2.14.5-release...2.15-release) [Previous Releases](https://github.com/Nevcairiel/HereBeDragons/releases)

- Update TOCs  
- Update TOC versions  
- Add data for Mists Classic  
- Remove pre-TWW retail data  
